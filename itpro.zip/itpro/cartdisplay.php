<?php
session_start();
include 'connect.php';
$query = "select *from cart";
$result = mysqli_query($con,$query);
$query1 = "select SUM(price) as sum from cart";
$result1 = mysqli_query($con,$query1);
$row1 = mysqli_fetch_assoc($result1);
$total=$row1['sum'];
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}
.error {color: #FF0000;}
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
 text-align:center;
background-image:url("bg.jpeg");
background-repeat:no-repeat;
background-size:cover;
margin:0;

}
 div.head {
  font-family: Purisa, sans-serif;
  font-size:60;
  color:white;
  }
 div.container {
 
    width:auto; 
    margin:1%;
    position: auto;
  
    left:8%;
   
    opacity:5%;
  }
  img {vertical-align: middle;
width:70%;
height:70%;}
  .lol
{
 border:2px solid black;
    width:30%;
    height:50%; 
    margin:1%;
   position: auto;
   align:center;
   }
   .topnav {
  overflow: hidden;
  background-color: #F00000;
   position: auto;
    
   width: 100%;
}

.topnav a {
  float: right;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #111111;
  color: white;
}

.topnav a.active {
  background-color: #F00000;
  color: white;
  }
 div.hmm {
 background-color:white;
 border:1px solid black:
  width:auto; 
    margin:1%;
    position: auto;
  left:8%;
   opacity:5%;
   button-color:red;
  }
  div.total {
 border:1px solid black:
  width:auto; 
    margin:1%;
    position: fixed;
  right:17%;
  
  }
  </style>
  
  </head>
<body>
<div class="head">Surprise...!</div>
<div class="topnav">

  <a class="" href="reg1.html">Home</a>
  <a href="#about">About</a>
  <a href="display.php">Gifts</a>
  <a href="cartdisplay.php"><i class="fa fa-shopping-cart" style="font-size:24px;color:white"></i></a>
  </div>
<div class="container">


<table width="auto">
<thead>
<th>PRODUCT</th>
<th>PRODUCT NAME</th>
<th>QUANTITY</th>
<th>PRICE</th>
<th>CANCEL</th>
</thead>
		
		
	<?php 
	while($row = mysqli_fetch_array($result)){?>
	
		
		
	<tbody><tr border="1px solid">
	<div class="hmm">
		
		<td align="center" width="50%" > 
		<div class="lol">
			<?php $image= $row['image'] ;
			 $img="uploads/".$image;
			 echo'<img src="'.$img.'" width="20%" height="20%">';?>  </div></td>
			 
		<td> <?php echo $row['category'] ?></td>
		<td> <?php echo $row['quantity'] ?></td>
		<td> <?php echo $row['price']?></td>
		<td> 
		<a href="cancel.php?page=items&action=add&id=<?php echo $row['pro_id'] ?>"><button>cancel</button></a>
		</td> 

 


 </div>
  
   </tr>
   </tbody>
   
  
    
				<?php } ?>
				
				</table>
				<div class="total">
				TOTAL &nbsp;&nbsp;
				 <td>Rs. <?php echo $total;?></td>
				 
				 </div>
				</br>
				</br>
				
</form> 
</br>
</br>
		</div>
					
		<div class="head"> <a href="login.php"><button> PROCEED TO CHECKOUT</button></a></div>
		
		</body>
		</html>
		
		
