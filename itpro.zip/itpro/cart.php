<?php
session_start();
include 'connect.php';

    if(isset($_GET['action']) && $_GET['action']=="add"){ 
          
        $id=intval($_GET['id']); 
          
       


$query = "select *from items where pro_id='$id'";
$result = mysqli_query($con,$query) or die('error querying database'.mysqli_error($con));
while($row = mysqli_fetch_array($result)){
$id=$row['pro_id'];
$img=$row['userfile'];
$cat=$row['category'];
$price=$row['price'];
$query1 = "insert into cart(pro_id,image,category,price)values('$id','$img','$cat','$price') ";
$result1 = mysqli_query($con,$query1) or die('error querying database'.mysqli_error($con));
if($result1==TRUE)
{
 $msg="added to cart succesfully";
  echo "<script>
  alert('your product has been uploaded to cart');
        window.location.href='display.php';
        </script>";
        }
        }
        }
        
        ?>
