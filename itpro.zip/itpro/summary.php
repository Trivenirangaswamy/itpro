<?php
session_start();
include "connect.php";
$today=date("d/m/Y");
$query = "select *from cart";
$result = mysqli_query($con,$query);
?>
	<head>
<style>
* {box-sizing: border-box;}
.error {color: #FF0000;}
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
 text-align:center;
background-image:url("bg.jpeg");
background-repeat:no-repeat;
background-size:cover;
margin:0;

}
 div.head {
  font-family: Purisa, sans-serif;
  font-size:60;
  color:white;
  }
 div.container {
 
    width:auto; 
    margin:1%;
    position: auto;
  
    left:8%;
   
    opacity:5%;
  }
  img {vertical-align: middle;
width:70%;
height:70%;}
  .lol
{
 border:2px solid black;
    width:30%;
    height:50%; 
    margin:1%;
   position: auto;
   align:center;
   }
   </style>
   </head>
   <body>
	<div class="head">Surprise...!</div>	
	<div class="container">	
	<table width="auto">
<thead>
<th>PRODUCT</th>
<th>PRODUCT NAME</th>
<th>QUANTITY</th>
<th>PRICE</th>
<?php
$username=$_SESSION['username'];
while($row = mysqli_fetch_array($result)){?>
	<tbody><tr border="1px solid">
	<div class="hmm">
		
		<td align="center" width="50%" > 
		<div class="lol">
			<?php $image= $row['image'] ;
			 $img="uploads/".$image;
			 echo'<img src="'.$img.'" width="20%" height="20%">';?>  </div></td>
			 
		<td> <?php echo $row['category'] ?></td>
		<td> <?php echo $row['quantity'] ?></td>
		<td> <?php echo $row['price']?></td></div>
		</table>
		<?php
		

$query1 ="insert into order_details(date,username,pro_id,quantity,price)values('$today','$username','$row[pro_id]','$row[quantity]','$row[price]')";
$result1 = mysqli_query($con,$query1) or die("error querying database".mysqli_error($con));
}

?>

<a href="reg1.html"><button>FINALISE</button></a>
<a href="cartdisplay.php"><button>BACK</button></a>
</body>

