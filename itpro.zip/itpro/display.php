<?php
session_start();
include 'connect.php';
$query = "select *from items";
$result = mysqli_query($con,$query);
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
 text-align:center;
background-image:url("bg.jpeg");
background-repeat:no-repeat;
background-size:cover;
margin:0;

}
 div.head {
  font-family: Purisa, sans-serif;
  font-size:60px;
  color:white;
  }
 div.container {
 
    width:auto; 
    margin:1%;
    position: auto;
  
    left:8%;
   
    opacity:5%;
  }
  img {vertical-align: middle;
width:70%;
height:70%;}
  .lol
{
 border:2px solid black;
    width:30%;
    height:50%; 
    margin:1%;
   position: auto;
   align:center;
   }
   .topnav {
  overflow: hidden;
  background-color: #F00000;
   position: auto;
    
   width: 100%;
}

.topnav a {
  float: right;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #111111;
  color: white;
}

.topnav a.active {
  background-color: #F00000;
  color: white;
  }
 div.hmm {
 background-color:white;
 border:1px solid black:
  width:auto; 
    margin:1%;
    position: auto;
  left:8%;
   opacity:5%;
   button-color:red;
  }
  </style>
  
  </head>
<body>
<div class="head">Surprise...!</div>
<div class="topnav">

   <a class="" href="reg1.html">HOME</a>
  <a href="#about">ABOUT</a>
  <a href="display.php">PRODUCTS</a>
 <a href="cartdisplay.php"><i class="fa fa-shopping-cart" style="font-size:24px;color:white"></i></a>
  
  </div>
<div class="container">

<h1>GIFT ITEMS</h1>
<table width="auto">
<th colspan="2">ITEMS</th>
<th>PRICE</th>
<th>SELECT</th>
		
		
	<?php 
	while($row = mysqli_fetch_array($result)){?>
	
		<?php $_SESSION['id']=$row['pro_id'];?>
		
	<tr border="1px solid">
	<div class="hmm">
		
		<td align="center" width="50%" > 
		<div class="lol">
			<?php $image= $row['userfile'] ;
			 $img="uploads/".$image;
			 echo'<img src="'.$img.'" width="20%" height="20%">';?>  </div></td>
			 
		<td> <?php echo $row['category'] ?></td>
		<td> <?php echo $row['price']?></td>
<td><a href="cart.php?page=items&action=add&id=<?php echo $row['pro_id'] ?>"><button>Add to cart</button></a></td> 
 </div>
  
   </tr>
  
    
				<?php } ?>
				</table>
				</br>
				</br>
				
</form> 
</br>
</br>
		</div>
					
		
		
		</body>
		</html>
		
		
