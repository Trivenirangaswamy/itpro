<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}
.error {color: #FF0000;}
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
 text-align:center;
background-image:url("bg.jpeg");
background-repeat:no-repeat;
background-size: 1400px 800px;
margin:0;

}
 div.container {
 border:1px solid black;
    width:50%; 
    margin:1%;
    position: fixed;
    top: 5%;
    left:20%;
    background-color:white;
  }
  </style>
  </head>
<body>
<div class="container">
<h1> UPLOAD PRODUCT DETAILS</h1>
<form method="post" action="up.php" enctype="multipart/form-data">
Category:<select name="category">
  <option value="greeting">greetings</option>
  <option value="chocolate">chocolate</option>
  <option value="teddy bears">teddy bear</option>
  <option value="watches">watches</option>
</select>

</br>
</br>
</br>
Price:<input type="text" name="price" />
</br>
</br>
</br>
Upload an image here:
<input type="hidden" name="MAX_FILE_SIZE" value="2000000" />
<input id="userfile" type="file" name="userfile" />

<input id="upload" type="submit" name="upload" value="upload" />
</form>

</br></br></br>
<a href="remove_0.php"><button>VIEW PREVIOUS UPLOADS</button></a></br></br></br></br>
</div>

</body>
</html>

