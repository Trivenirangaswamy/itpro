<?php
include('connect.php');
if(isset($_GET['remove_number']))
{
	$res=mysqli_query($con,"SELECT * FROM items WHERE number=".$_GET['remove_number']);
	$row=mysqli_fetch_array($res);
	mysqli_query($con,"DELETE FROM items WHERE number=".$_GET['remove_number']);
	unlink("uploads/".$row['userfile']);
	header("Location:remove_0.php");
	echo "deleted sucessfully";
}
?>
